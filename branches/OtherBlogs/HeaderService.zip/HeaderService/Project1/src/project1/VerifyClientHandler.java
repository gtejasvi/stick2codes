package project1;

import java.io.IOException;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.ws.soap.SOAPFaultException;

public class VerifyClientHandler implements SOAPHandler<SOAPMessageContext>{
    public VerifyClientHandler() {
        super();
    }

    @Override
    public Set<QName> getHeaders() {
        return Collections.emptySet();
    }

    @Override
    public boolean handleMessage(SOAPMessageContext context) {
        System.out.println("In handleMessage()");

        Boolean isRequest =
            (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY); //For incoming message, this value will be false
        System.out.println(isRequest);

        if (!isRequest) {
            System.out.println("Here");
            try {
                SOAPMessage soapMsg = context.getMessage();
                SOAPEnvelope soapEnv = soapMsg.getSOAPPart().getEnvelope();
                SOAPHeader soapHeader = soapEnv.getHeader();
                System.out.println("SOAP Header:" + soapHeader);
                if (soapHeader == null) {
                    msgSOAPError(soapMsg, "No Header. Please pass header data ");
                }
                Iterator it = soapHeader.extractAllHeaderElements();

                if (it == null || !it.hasNext()) {
                    msgSOAPError(soapMsg, "No header block.");
                }

                //if no mac address found? throw exception
                Node clientNode = (Node) it.next();
                String clientValue = (clientNode == null) ? null : clientNode.getValue();

                if (clientValue == null) {
                    msgSOAPError(soapMsg, "No client info in the header block.");
                }

                //if mac address is not match, throw exception
                if (!clientValue.equals("ClientABC")) {
                    msgSOAPError(soapMsg, "Invalid Client---Access denied.");
                }

                //tracking
                soapMsg.writeTo(System.out);

            } catch (SOAPException e) {
                System.err.println(e);
            } catch (IOException e) {
                System.err.println(e);
            }

        }

        //continue other handler chain
        return true;
        }

        private void msgSOAPError(SOAPMessage msg, String reason) {
        try {
            SOAPBody soapBody = msg.getSOAPPart().getEnvelope().getBody();
            SOAPFault soapFault = soapBody.addFault();
            soapFault.setFaultString(reason);
            throw new SOAPFaultException(soapFault);
        } catch (SOAPException e) {
        }
        }


    @Override
    public boolean handleFault(SOAPMessageContext context) {
        return false;
    }

    @Override
    public void close(javax.xml.ws.handler.MessageContext context) {
    }
}
