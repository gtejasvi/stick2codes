package project1;

import javax.jws.HandlerChain;
import javax.jws.WebService;

import weblogic.wsee.jws.jaxws.owsm.SecurityPolicy;

@WebService
@HandlerChain(file = "HandlerXML.xml")
@SecurityPolicy(uri = "oracle/wss_username_token_service_policy")
public class Hello {
    public Hello() {
        super();
    }
    
    public String helloWorld() {
        System.out.println("Heloooo");
        return "Hello ";
    }
}
