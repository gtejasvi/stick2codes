package employeeproj;

import java.util.ArrayList;
import java.util.Iterator;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("employeeproj")
public class EmpService {
    static ArrayList<Employee> EmpList = new ArrayList<Employee>();

    public EmpService() {
        Employee emp1 = new Employee();
        addEmp();
    }

    @GET
    @Produces("application/xml")
    public ArrayList<Employee> getEmpList() {
        return EmpList;
    }

    @PUT
    @Consumes("application/xml")
    @Produces("application/xml")
    public ArrayList<Employee> addEmployee(Employee emp) {
        EmpList.add(emp);
        return EmpList;
    }

    @DELETE
    @Path("{name}")
    public ArrayList<Employee> deleteEmployee(@PathParam("name") String name) {
        EmpList.remove(getEmp(name));
        return EmpList;
    }

    @POST
    @Produces("application/json")
    @Path("{name}")
    public ArrayList<Employee> updateEmployee(@PathParam("name") String name) {
        Employee emp1 = new Employee();
        emp1 = getEmp("Arnold");
        if (emp1 != null)

            emp1.setName(name);
        return EmpList;
    }

    public Employee getEmp(String name) {
        Iterator i = EmpList.iterator();
        while (i.hasNext()) {
            Employee e = (Employee)i.next();
            if (e.getName().equalsIgnoreCase(name))
                return e;
        }
        return null;
    }

    public void addEmp() {
        if (EmpList.isEmpty()) {
            Employee emp1 = new Employee();
            emp1.setId(1);
            emp1.setName("Arnold");
            EmpList.add(emp1);
        }
    }
}
