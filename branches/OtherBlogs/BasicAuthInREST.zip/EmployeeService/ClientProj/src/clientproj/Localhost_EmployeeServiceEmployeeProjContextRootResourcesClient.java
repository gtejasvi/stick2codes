package clientproj;

import com.sun.jersey.api.client.Client;

import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

import java.net.Authenticator;

import java.net.PasswordAuthentication;

import javax.annotation.Generated;

@Generated({ "Oracle JDeveloper", "run|a7fb8a86-81b8-4c50-9934-7c21db60caf7" })
public class Localhost_EmployeeServiceEmployeeProjContextRootResourcesClient {
    public static void main(String[] args) {
        Client client = Localhost_EmployeeServiceEmployeeProjContextRootResources.createClient();

        Localhost_EmployeeServiceEmployeeProjContextRootResources.Employeeproj localhost_employeeserviceemployeeprojcontextrootresourcesemployeeproj =
            Localhost_EmployeeServiceEmployeeProjContextRootResources.employeeproj(client);
        
        // add your code here
        //client.addFilter(new HTTPBasicAuthFilter("weblogic","weblogic1"));
        
        Authenticator.setDefault(new MyAuthenticator());
        System.out.println(localhost_employeeserviceemployeeprojcontextrootresourcesemployeeproj.getAsXml(String.class));
    }
    
    static class MyAuthenticator extends Authenticator {    
        public PasswordAuthentication getPasswordAuthentication() {
                
        return (new PasswordAuthentication("weblogic", "weblogic1".toCharArray()));
            }
        } 
} 