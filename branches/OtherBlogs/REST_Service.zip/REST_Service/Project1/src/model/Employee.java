package model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {
    String name;
    int id;
   
    public Employee() {
        super();
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}