package newReleasePack;

import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import java.util.StringTokenizer;

import oracle.adfmf.dc.ws.rest.RestServiceAdapter;
import oracle.adfmf.framework.api.Model;
import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;

import org.kxml2.io.KXmlParser;

import org.xmlpull.v1.XmlPullParser;

import sun.misc.Service;

public class NewReleaseDCClass {

    private static List newReleasesList = new ArrayList();
    private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public NewReleaseDCClass() {
        super();
    }

    public void setNewReleasesList(List newReleasesList) {
        List oldNewReleasesList = NewReleaseDCClass.newReleasesList;
        NewReleaseDCClass.newReleasesList = newReleasesList;
        propertyChangeSupport.firePropertyChange("newReleasesList", oldNewReleasesList, newReleasesList);
    }

    public static List getNewReleasesList() {
        return newReleasesList;
    }

    public void addPropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }

    public NewReleases[] allNewReleases() {
        String response = "";
        try {
            HttpURLConnection ucon = null;
            //Use your AWSAccessKeyId where it says ####; Use your AssociateTag where it says #### 
            URL url =
                new URL("http://free.apisigning.com/onca/xml?AWSAccessKeyId=####&Service=AWSECommerceService&Operation=BrowseNodeLookup&BrowseNodeId=283155&ResponseGroup=NewReleases&Version=2011-08-01&AssociateTag=####");
            ucon = (HttpURLConnection)url.openConnection();
            ucon.setFollowRedirects(false); //to stop auto redirect
            ucon.setInstanceFollowRedirects(false); //to stop auto redirect
            ucon.connect();
            System.out.println("Connected to free signing");
            String newUrlLoc = ucon.getHeaderField("Location"); //extract the value of Location header which contains the new URL with timestamp & signature
            System.out.println(" After  getting response code");
            ucon.disconnect(); //disconnect from free.apisigning.com
            System.out.println("After  disconnect ");
            URL newUrl = new URL(newUrlLoc); //connect to new URL to get the query parameters
            String requestQuery = newUrl.getQuery(); // get the query parameters
            
            RestServiceAdapter restServiceAdapter = Model.createRestServiceAdapter();
            restServiceAdapter.clearRequestProperties();
            restServiceAdapter.setConnectionName("conn"); //URL connection to http://webservices.amazon.com/onca/xml
            restServiceAdapter.setRequestURI("?"+requestQuery); // appending the parameters with timestamp & signature
            restServiceAdapter.setRequestType(RestServiceAdapter.REQUEST_TYPE_GET);
            restServiceAdapter.addRequestProperty("Content-Type", "text/xml;charset=UTF-8");
            restServiceAdapter.addRequestProperty("Accept", "application/xml");
            restServiceAdapter.setRetryLimit(0);
            response = restServiceAdapter.send("");
            System.out.println("Response received!" + response);
            
            //parsing the response. Refer http://stick2code.blogspot.com/2014/04/xml-parsing-in-adf-mobile.html for explanation
            KXmlParser parser = new KXmlParser(); //create a parser instance
            Reader stream = new StringReader(response);
            parser.setInput(stream);
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "BrowseNodeLookupResponse");
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "OperationRequest");
            parser.skipSubTree();
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "BrowseNodes");
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "Request");
            parser.skipSubTree();
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "BrowseNode");
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "BrowseNodeId");
            parser.nextText();
            parser.require(XmlPullParser.END_TAG, null, "BrowseNodeId");
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "Name");
            parser.nextText();
            parser.require(XmlPullParser.END_TAG, null, "Name");
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "NewReleases");
            while (parser.nextTag() != XmlPullParser.END_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "NewRelease");
                NewReleases newRelaseObj = new NewReleases();
                while (parser.nextTag() != XmlPullParser.END_TAG) {
                    String tagName = parser.getName();
                    if (tagName.equals("ASIN")) {
                        String asin = parser.nextText();
                        newRelaseObj.setASIN(asin);
                    } else if (tagName.equals("Title")) {
                        String title = parser.nextText();
                        newRelaseObj.setTitle(title);
                    }
                    parser.require(XmlPullParser.END_TAG, null, tagName);
                }
                newReleasesList.add(newRelaseObj);
                parser.require(XmlPullParser.END_TAG, null, "NewRelease");
            }
            parser.require(XmlPullParser.END_TAG, null, "NewReleases");
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "TopItemSet");
            parser.skipSubTree();
            parser.nextTag();
            parser.require(XmlPullParser.END_TAG, null, "BrowseNode");
            parser.nextTag();
            parser.require(XmlPullParser.END_TAG, null, "BrowseNodes");
            parser.nextTag();
            parser.require(XmlPullParser.END_TAG, null, "BrowseNodeLookupResponse");
            NewReleases[] newRel = (NewReleases[])newReleasesList.toArray(new NewReleases[newReleasesList.size()]); //store the ASIN and titles in an array
            return newRel;
        } catch (InvalidKeyException e) {
            System.out.println("InvalidKeyException" + e);
        } catch (NoSuchAlgorithmException e) {
            System.out.println("NoSuchAlgorithmException" + e);
        } catch (UnsupportedEncodingException e) {
            System.out.println("UnsupportedEncodingException" + e);
        } catch (Exception e) {
            System.out.println("Exception" + e);
            System.out.println(e.getStackTrace());
            e.printStackTrace();
        }
        return null;
    }
}
