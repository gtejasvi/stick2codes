package newReleasePack;

public class NewReleases {
    private String ASIN;
    private String Title;
    public NewReleases() {
        super();
    }
    
    public void setASIN(String ASIN) {
        this.ASIN = ASIN;
    }

    public String getASIN() {
        return ASIN;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getTitle() {
        return Title;
    }
    
}
