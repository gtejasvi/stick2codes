package project1;
/**
 * This class has three employee attributes and their corresponding getters and setters
 */
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {
    private int empID;
    private String name;
    private int salary;

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public int getEmpID() {
        return empID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }

    public Employee() {
        super();
    }
}
