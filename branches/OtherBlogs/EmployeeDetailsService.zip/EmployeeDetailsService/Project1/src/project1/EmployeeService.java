package project1;
/**
 * This is the service class with a single GET method.
 * Uses JAXRS 2.0
 */
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("Employee")
public class EmployeeService {
    private static List<Employee> employeeList = new CopyOnWriteArrayList<Employee>();
    @HeaderParam("Client-Name") String client;

    public EmployeeService() {
        super();
        Employee emp = new Employee();
        emp.setEmpID(1);
        emp.setName("Jerry");
        emp.setSalary(30000);
        employeeList.add(emp);
    }

    /**
     * In this method, the request header param 'Client-Name' is extracted using @HeaderParam annotation.
     * If the header param is absent, client is shown a 404 error message with suitable message.
     * Only if the header param is present and has a value of 'Oracle Corp', employee details are shown.
     * @param client
     * @return
     */
    @GET
    @Produces("application/xml")
    public Response getEmpList() {
        if (client == null || client == "") {
            System.out.println("Client :" + client);
            return Response.status(404).entity("Client details required").build();
        } else if (client.equalsIgnoreCase("My Client")) {
            System.out.println("Client-Name:" + client);
            return Response.status(200).entity(new EmployeeList(employeeList)).build();
        } else {
            return Response.status(401).entity("Not authorized to view the details").build();
        }

    }
}
