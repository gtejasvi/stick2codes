package project1;

import java.util.List;

import javax.annotation.Resource;

import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless(name = "SessionEJB", mappedName = "EJB_Service-Project1-SessionEJB")
@Local
@WebService(name = "SessionEJBBeanService", portName = "SessionEJBBeanServicePort")
public class SessionEJBBean {
    @Resource
    SessionContext sessionContext;
    @PersistenceContext(unitName = "Project1")
    private EntityManager em;

    public SessionEJBBean() {
    }

    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    @WebMethod
    public Object queryByRange(@WebParam(name = "arg0") String jpqlStmt, @WebParam(name = "arg1") int firstResult,
                               @WebParam(name = "arg2") int maxResults) {
        Query query = em.createQuery(jpqlStmt);
        if (firstResult > 0) {
            query = query.setFirstResult(firstResult);
        }
        if (maxResults > 0) {
            query = query.setMaxResults(maxResults);
        }
        return query.getResultList();
    }

    @WebMethod(exclude = true)
    public <T> T persistEntity(T entity) {
        em.persist(entity);
        return entity;
    }

    @WebMethod(exclude = true)
    public <T> T mergeEntity(T entity) {
        return em.merge(entity);
    }

    @Oneway
    @WebMethod
    public void removeEmployees(@WebParam(name = "arg0") Employees employees) {
        employees = em.find(Employees.class, employees.getEmployeeId());
        em.remove(employees);
    }

    /** <code>select o from Employees o</code> */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    @WebMethod
    public List<Employees> getEmployeesFindAll() {
        return em.createNamedQuery("Employees.findAll", Employees.class).getResultList();
    }

    @Oneway
    @WebMethod
    public void removeDepartments(@WebParam(name = "arg0") Departments departments) {
        departments = em.find(Departments.class, departments.getDepartmentId());
        em.remove(departments);
    }

    /** <code>select o from Departments o</code> */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    @WebMethod
    public List<Departments> getDepartmentsFindAll() {
        return em.createNamedQuery("Departments.findAll", Departments.class).getResultList();
    }

    @WebMethod
    public List<Employees> getEmpFindEmpByID(@WebParam(name = "arg0") Integer empnumber) {
        em.flush();
        return em.createNamedQuery("Employees.findEmpByID", Employees.class).setParameter("empnumber",
                                                                                          empnumber).getResultList();
    }

    @WebMethod
    public List<Departments> getEmpFindEmpByDeptID(@WebParam(name = "arg0") Integer deptnumber) {
        em.flush();
        System.out.println(deptnumber);
        System.out.println("Query:" +
                           em.createNamedQuery("Departments.findEmpByDeptID",
                                               Departments.class).setParameter("deptnumber", deptnumber));
        List<Departments> depList =
            em.createNamedQuery("Departments.findEmpByDeptID", Departments.class).setParameter("deptnumber",
                                                                                               deptnumber).getResultList();
        System.out.println("Size:" + depList.size());

        for (int i = 0; i < depList.size(); i++) {
            List<Employees> empList = depList.get(0).getEmployeesList1();
            System.out.println(empList.size());
        }
        return depList;
    }

    //insert new department/employee
    @WebMethod
    public List<Departments> createNewRecord(@WebParam(name = "arg0") Departments dept) {
        if(dept == null || dept.equals("")) return null;
        Employees emp = dept.getEmployeesList1().get(0);
        emp.setDepartments(dept);
        em.persist(dept);
        em.persist(emp);
        return em.createNamedQuery("Departments.findAll", Departments.class).getResultList();
    }
    //update department/employee details
    @WebMethod
    public List<Departments> updateRecord(@WebParam(name = "arg0") Departments dept) {
        em.merge(dept);
        return em.createNamedQuery("Departments.findAll", Departments.class).getResultList();
    }
}
