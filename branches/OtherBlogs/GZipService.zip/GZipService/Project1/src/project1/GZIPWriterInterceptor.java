package project1;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.WriterInterceptor;
import javax.ws.rs.ext.WriterInterceptorContext;

@Provider
@Compressor
public class GZIPWriterInterceptor implements WriterInterceptor {
    public GZIPWriterInterceptor() {
        super();
    }
    private HttpHeaders context;

    public GZIPWriterInterceptor(@Context HttpHeaders context) {
        this.context = context;
    }

    @Override
    public void aroundWriteTo(WriterInterceptorContext writerInterceptorContext) throws IOException,WebApplicationException {
        // TODO Implement this method
        String acceptEncoding = context.getHeaderString("Accept-Encoding");
        if (acceptEncoding != null && acceptEncoding.contains("gzip")) {
            final OutputStream outputStream = writerInterceptorContext.getOutputStream();
            writerInterceptorContext.setOutputStream(new GZIPOutputStream(outputStream));
            writerInterceptorContext.getHeaders().putSingle("Content-Encoding", "gzip");
        }
        writerInterceptorContext.proceed();

    }
}