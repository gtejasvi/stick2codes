var EmpClientClient = {
rootUri : "http://localhost:7101/REST_Service-Project1-context-root/resources/",
EmpClient : function() 
{
var path0 = EmpClientClient.rootUri;
return {
Project1 : function() 
{
var path1 = path0+"project1";
return {
SearchEmpId : function(id) 
{
var path2 = path1+"/"+"searchEmp/{id}";
path2 = path2.replace(/\{id.*?\}/, id);
return {
// Required: Optional: name 
getAsJson : function(name) 
{
var queryPart = {

}
;
if (name !== undefined && name !== null)
{
queryPart.name = name;

}
path2 = path2 + '?' + $.param(queryPart);
return $.ajax(path2, {
type : "GET",
headers : {
Accept : "application/json"
}

}
);

}

}
;

}
,
UpdateEmp : function() 
{
var path2 = path1+"/"+"updateEmp";
return {
// Required: Entity: requestEntity Optional: 
postXml : function(requestEntity) 
{
return $.ajax(path2, {
type : "POST",
contentType : "application/xml",
data : requestEntity,
headers : {
Accept : "application/xml"
}

}
);

}

}
;

}
// Required: Optional: 
,
getAsJson : function() 
{
return $.ajax(path1, {
type : "GET",
headers : {
Accept : "application/json"
}

}
);

}
// Required: Entity: requestEntity Optional: 
,
putJson : function(requestEntity) 
{
return $.ajax(path1, {
type : "PUT",
contentType : "application/json",
data : JSON.stringify(requestEntity),
headers : {
Accept : "application/json"
}

}
);

}
// Required: Optional: name 
,
deleteAsJson : function(name) 
{
var queryPart = {

}
;
if (name !== undefined && name !== null)
{
queryPart.name = name;

}
path1 = path1 + '?' + $.param(queryPart);
return $.ajax(path1, {
type : "DELETE",
headers : {
Accept : "application/json"
}

}
);

}

}
;

}

}
;

}

}
;
