package empservice;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(propOrder={"list","count"})
public class EmployeeList {
    
    private List<Employee> list = new ArrayList<Employee>();  
    
    private int count;
    public EmployeeList() {
        
    }

    public EmployeeList(List<Employee> list) {
        super();
        this.list = list;
        this.count = this.list.size();
    }

//    @XmlElement
    public List<Employee> getList() {
        return list;
    }
    
//    @XmlElement
    public int getCount() {
        return count;
        }
}