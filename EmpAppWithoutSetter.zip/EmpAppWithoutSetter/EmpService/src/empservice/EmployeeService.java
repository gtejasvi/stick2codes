package empservice;

import java.util.Iterator;

import java.util.List;

import java.util.concurrent.CopyOnWriteArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("project1")
public class EmployeeService {

    private static List<Employee> employeeList = new CopyOnWriteArrayList<Employee>();

    public EmployeeService() {
        addEmp();
    }

    @GET
    @Produces("application/xml")
    public EmployeeList getEmpList() {      
        return new EmployeeList(employeeList);
    }
    
    @PUT
    @Consumes("application/xml")
    @Produces("application/xml")
    public EmployeeList addEmployee(Employee emp) {
        employeeList.add(emp);
        return new EmployeeList(employeeList);
    }

    @DELETE
    @Produces("application/xml")
    public EmployeeList deleteEmployee(@QueryParam("name") String name) {
        employeeList.remove(getEmp(name));
        return new EmployeeList(employeeList);
    }
    
    @POST
    @Produces("application/xml")
    public EmployeeList updateEmployee(@QueryParam("id") int id,@QueryParam("name") String name) {
        Employee emp1 = new Employee();
        emp1 = getEmpById(id);
        if(emp1 != null)
            emp1.setName(name);
        return new EmployeeList(employeeList);
    }

    public Employee getEmp(String name) {
        Iterator i = employeeList.iterator();
        while (i.hasNext()) {
            Employee e = (Employee)i.next();
            if (e.getName().equalsIgnoreCase(name))
                return e;
        }
        return null;
    }
    
    public Employee getEmpById(int id) {
        Iterator i = employeeList.iterator();
        while (i.hasNext()) {
            Employee e = (Employee)i.next();
            if (e.getId() == id)
                return e;
        }
        return null;
    }

    public void addEmp() {
        if (employeeList.isEmpty()) {
            Employee emp1 = new Employee();
            emp1.setId(1);
            emp1.setName("Arnold");
            employeeList.add(emp1);
        }
    }
}